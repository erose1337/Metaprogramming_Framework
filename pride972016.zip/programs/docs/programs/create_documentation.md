mpre.programs.create_documentation
==============



Documentation_Creator
--------------

	No docstring found


Instance defaults: 

	{'_deleted': False,
	 'delete_verbosity': 'vv',
	 'dont_save': False,
	 'object_name': '',
	 'parse_args': True,
	 'replace_reference_on_load': True,
	 'verbosity': ''}

Method resolution order: 

	(<class 'mpre.programs.create_documentation.Documentation_Creator'>,
	 <class 'mpre.base.Base'>,
	 <type 'object'>)