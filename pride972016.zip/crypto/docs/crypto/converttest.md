crypto.converttest
==============



Test_Cipher
--------------

	No documentation available


Method resolution order: 

	(<class 'crypto.converttest.Test_Cipher'>,
	 <class 'pride.crypto.Cipher'>,
	 <type 'object'>)

- **encrypt_block**(self, data, key):

				No documentation available


- **decrypt_block**(self, data, key):

				No documentation available


convert
--------------

**convert**(old_value, old_base, new_base):

				No documentation available


decrypt
--------------

**decrypt**(data, key, conversion_key, conversion_key2):

				No documentation available


diffusion_transformation
--------------

**diffusion_transformation**(_bytes):

				No documentation available


encrypt
--------------

**encrypt**(data, key, conversion_key, conversion_key2):

				No documentation available


generate_key
--------------

**generate_key**(size, seed):

				No documentation available


invert_diffusion_transformation
--------------

**invert_diffusion_transformation**(_bytes):

				No documentation available


key_schedule
--------------

**key_schedule**(key):

				No documentation available


replacement_subroutine
--------------

**replacement_subroutine**(bytearray1, bytearray2):

				No documentation available


shuffle
--------------

**shuffle**(data, key):

				No documentation available


test_convert
--------------

**test_convert**():

				No documentation available


test_diffusion_transformation
--------------

**test_diffusion_transformation**():

				No documentation available


test_encrypt_decrypt
--------------

**test_encrypt_decrypt**():

				No documentation available


xor_subroutine
--------------

**xor_subroutine**(bytearray1, bytearray2):

				No documentation available


xor_sum
--------------

**xor_sum**(data):

				No documentation available
