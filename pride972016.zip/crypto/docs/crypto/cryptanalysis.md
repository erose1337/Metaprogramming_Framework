crypto.cryptanalysis
==============



cryptanalyze_sbox
--------------

**cryptanalyze_sbox**(sbox, differential_types):

				No documentation available


summarize_sbox
--------------

**summarize_sbox**(sbox, differential_types):

				No documentation available


test_cryptanalyze_sbox
--------------

**test_cryptanalyze_sbox**():

				No documentation available
