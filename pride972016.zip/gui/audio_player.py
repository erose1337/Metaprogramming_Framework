import pride.gui.gui
class audio_player(pride.gui.gui.Application): pass