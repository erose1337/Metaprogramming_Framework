from ciphercomponents import rotate_left, choice

def rotl64(word, amount):
    return rotate_left(word, amount, 64)
    
def round_function(a, b, c, d):
    a ^= rotl64(choice(b, c, d), 1);
    b ^= rotl64(choice(c, d, a), 2);
    c ^= rotl64(choice(d, a, b), 3);
    d ^= rotl64(choice(a, b, c), 4);
    
    a = choice(c, a, b)
    b = choice(c, b, a)    
    c = choice(b, c, d)
    d = choice(b, d, c)    
    
    
    
    return a, b, c, d
    
def test_round_function():
    from visualizationtest import test_4x64_function
    test_4x64_function(round_function, (0, 1, 2, 3))
    
if __name__ == "__main__":
    test_round_function()
    