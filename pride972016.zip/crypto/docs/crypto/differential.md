crypto.differential
==============



build_difference_distribution_table
--------------

**build_difference_distribution_table**(sbox, differences):

				No documentation available


calculate_differential_chain
--------------

**calculate_differential_chain**(xor_ddt, input_difference):

				No documentation available


cast
--------------

**cast**(input_data, _type):

				No documentation available


differential_attack
--------------

**differential_attack**(encryption_function, cipher_s_box, blocksize, first_differential, trail_length_range):

				No documentation available


find_best_differential
--------------

**find_best_differential**(sbox, functions):

				No documentation available


find_best_differential_in_table
--------------

**find_best_differential_in_table**(difference_table):

		 Returns the single best xor differential for the supplied sbox.
        Output consists of the input difference, output difference, and
        probability that the difference will hold. 


find_best_output_differential
--------------

**find_best_output_differential**(xor_ddt, input_difference):

				No documentation available


find_impossible_differentials
--------------

**find_impossible_differentials**(xor_ddt):

				No documentation available


modular_addition
--------------

**modular_addition**(x, y, modulus):

				No documentation available


modular_multiplication
--------------

**modular_multiplication**(x, y, modulus):

				No documentation available


modular_subtraction
--------------

**modular_subtraction**(x, y, modulus):

				No documentation available


rotate
--------------

**rotate**(input_string, amount):

				No documentation available


rotate_left
--------------

**rotate_left**(x, r, bit_width, _mask):

				No documentation available


rotational_difference
--------------

**rotational_difference**(input_one, input_two):

				No documentation available


test_build_difference_distribution_table
--------------

**test_build_difference_distribution_table**():

				No documentation available


test_calculate_differential_chain
--------------

**test_calculate_differential_chain**():

				No documentation available


test_differential_attack
--------------

**test_differential_attack**():

				No documentation available


test_find_impossible_differentials
--------------

**test_find_impossible_differentials**():

				No documentation available


xor
--------------

**xor**(x, y):

				No documentation available
